import streamlit as st
import joblib

model = joblib.load("fake_news_model.pkl")
vectorizer = joblib.load("vectorizer.pkl")

st.title("Fake News Detection System")

news = st.text_area("Enter News Text")

if st.button("Check"):
    transformed = vectorizer.transform([news])
    prediction = model.predict(transformed)[0]

    if prediction == "fake":
        st.error("Fake News")
    else:
        st.success("Real News")
