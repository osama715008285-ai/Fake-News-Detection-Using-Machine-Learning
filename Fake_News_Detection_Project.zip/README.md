# Fake News Detection Project

Machine Learning project using NLP and Logistic Regression.
